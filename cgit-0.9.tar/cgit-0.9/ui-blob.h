#ifndef UI_BLOB_H
#define UI_BLOB_H

extern int cgit_print_file(char *path, const char *head);
extern void cgit_print_blob(const char *hex, char *path, const char *head);

#endif /* UI_BLOB_H */
