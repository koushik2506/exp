#ifndef UI_PATCH_H
#define UI_PATCH_H

extern void cgit_print_patch(char *hex, const char *prefix);

#endif /* UI_PATCH_H */
