#ifndef UI_TAG_H
#define UI_TAG_H

extern void cgit_print_tag(char *revname);

#endif /* UI_TAG_H */
