#ifndef UI_REPOLIST_H
#define UI_REPOLIST_H

extern void cgit_print_repolist();
extern void cgit_print_site_readme();

#endif /* UI_REPOLIST_H */
