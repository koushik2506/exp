#ifndef UI_SUMMARY_H
#define UI_SUMMARY_H

extern void cgit_print_summary();
extern void cgit_print_repo_readme(char *path);

#endif /* UI_SUMMARY_H */
