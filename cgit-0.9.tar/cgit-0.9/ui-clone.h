#ifndef UI_CLONE_H
#define UI_CLONE_H

void cgit_clone_info(struct cgit_context *ctx);
void cgit_clone_objects(struct cgit_context *ctx);
void cgit_clone_head(struct cgit_context *ctx);

#endif /* UI_CLONE_H */
