#define version_string "0.48"
#define release_string "20090802"
