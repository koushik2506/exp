
#include "pnm.h"

void readtga(char *name,pix *p,int mode); // mode: 0=gray 1=RGB

// ------------------------------------------------------------------------
